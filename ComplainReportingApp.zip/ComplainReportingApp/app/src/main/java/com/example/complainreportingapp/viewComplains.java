package com.example.complainreportingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.GridView;

import java.util.ArrayList;

public class viewComplains extends AppCompatActivity {

    private GridView gridView;
    private ArrayList<String> list;
    private ArrayAdapter<String> adapter;
    MyHelper handler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.complainsview);

        gridView=(GridView) findViewById(R.id.gridView1);

    }
}
