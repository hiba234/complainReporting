package com.example.complainreportingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Signup extends AppCompatActivity {
    MyHelper db;
    EditText mTextUsername;
    EditText mTexPassword;
    EditText getTexCnfPassword;
    Button mButtonRegister;
    TextView mTextViewLogin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);
        db=new MyHelper(this);
        mTextUsername=findViewById(R.id.username);
        mTexPassword=findViewById(R.id.password);
        getTexCnfPassword=findViewById(R.id.confirm_password);
        mButtonRegister=findViewById(R.id.button_register);
        mTextViewLogin=findViewById(R.id.button_login);
        mTextViewLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i= new Intent(Signup.this,Login.class);
                startActivity(i);
            }
        });
        mButtonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user =mTextUsername.getText().toString().trim();
                String password =mTexPassword.getText().toString().trim();
                String conf_password =getTexCnfPassword.getText().toString().trim();

                if(password.equals(conf_password)){
                    long value= db.addUser(user,password);
                    if(value>0){
                        Toast.makeText(Signup.this,"You have Signup Successfully",Toast.LENGTH_SHORT).show();
                        Intent i= new Intent(Signup.this,Login.class);
                        startActivity(i);
                    }
                    else{
                        Toast.makeText(Signup.this,"Signup Error",Toast.LENGTH_SHORT).show();
                    }

                }
                else {
                    Toast.makeText(Signup.this,"Password is not matching",Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}